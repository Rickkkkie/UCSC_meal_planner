package WebScrapper;

import java.util.HashMap;
import java.util.LinkedList;

public class DailyMeals {
	private HashMap<String,LinkedList<String>> meals;
	private String name;
	
	public DailyMeals(String n) {
		name = n;
	}
	
	public  LinkedList<String> newMeal(String key) {
		return meals.put(key, new LinkedList<String>());
	}
	
	public  LinkedList<String> addMeal(String key, LinkedList<String> m) {
		return meals.put(key,m);
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
		
	}
	

}
