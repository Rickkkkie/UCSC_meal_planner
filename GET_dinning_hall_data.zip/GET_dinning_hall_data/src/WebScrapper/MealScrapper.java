package WebScrapper;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Timer;
import java.util.TimerTask;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.File;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.net.ssl.HttpsURLConnection;




 
public class MealScrapper {
	
	
	public static void main(String[] args) {
		 Timer timer = new Timer();
		  
	     Calendar calendar = Calendar.getInstance();
	     calendar.set(Calendar.HOUR_OF_DAY, 23);
	     calendar.set(Calendar.MINUTE, 20);
	     calendar.set(Calendar.SECOND, 0);
	     Date time = calendar.getTime();
	  
	     timer.schedule(new ScrapTask(),
	                     time);

	}
	
	public static void init() {
		dbUtil.conn();
		System.out.println("getting links to dininghalls...");
		/*Elements links = scrap("https://nutrition.sa.ucsc.edu/", " a[href]");

		for (Element link : links) {
			System.out.printf("%s\n\t%s\n", 
		     link.text(), link.absUrl("href"));
		}
		*/
		scrapGetCookies("https://nutrition.sa.ucsc.edu/");
		
		for (int i = 0;i<tables.length;i++) {
			String linkStr = urls[i];
	        String tname  = tables[i];	
			System.out.println(tname+":");
			Elements dishes = scrapFiles(linkStr, "div.shortmenumeals, div.shortmenurecipes span");
			HashMap<String, LinkedList<String>> meals = new HashMap<String,LinkedList<String>>();
			meals.put("Breakfast", new LinkedList<String>());  //id=1
			meals.put("Lunch", new LinkedList<String>());  //id=2
			meals.put("Dinner", new LinkedList<String>());  //id=3
			
			String curMeal = null;
			if(dishes!=null && dishes.size()!=0) {

				for (Element dish: dishes) {
					String dname = dish.text();
					if(dish.hasClass("shortmenumeals")) {
						//System.out.println("\t-----"+dname);
						curMeal = dname;
				
					}
					else {
						//System.out.println("\t"+dname);
						LinkedList<String> meal = meals.get(curMeal);
						if( meal != null)
							meal.add(dname);
						
					}
				}
				dailyUpdateIncrement(tname,meals.get("Breakfast"),1);
				dailyUpdateIncrement(tname,meals.get("Lunch"),2);
				dailyUpdateIncrement(tname,meals.get("Dinner"),3);
				

				System.out.println(meals);
				
			}
			
			
		}
		dbUtil.connClose();
	}
	
	
	static class ScrapTask extends TimerTask{
		
		public void run() {
			init();
		}
	}
	
	
	public static void dailyUpdateIncrement (String tname, LinkedList<String> meal, int id) {
		LinkedList<String> res = dbUtil.QueryFood(tname, id);
		LinkedList<String> toInsert = (LinkedList<String>) meal.stream()
				  .filter(Predicate.not(res::contains)).collect(Collectors.toCollection(LinkedList::new));
		System.out.println("toInsert: "+toInsert);
		dbUtil.IncrementTimeFood(tname, meal,id); //update must precede insert;
		dbUtil.InsertFood(tname, toInsert,id);


	}
	
	
	public static Elements scrapFiles(String iniLink, String selector) {
		Document doc;
		StringBuilder html = new StringBuilder();
		try {
			URL url = new URL(iniLink);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
		    con.setRequestProperty("Cookie", cookieStr);
		    // Send post request
		    con.setDoOutput(true);
		    con.setDoInput(true);
		    con.connect();
			String inputLine;;
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

			while ((inputLine = in.readLine()) != null)
			      html.append(inputLine);
			in.close();
			doc = Jsoup.parse(html.toString());
			Elements elems = doc.select(selector); // a with href
			return elems;
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
	
	
	public static Elements scrap(String iniLink, String selector) {
		Document doc;
		try {
			doc = Jsoup.connect(iniLink).get();
			Elements elems = doc.select(selector); // a with href
			return elems;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
	
	public static void scrapGetCookies(String iniLink) {
		Document doc;
		StringBuilder html = new StringBuilder();
		try {
			URL url = new URL(iniLink);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			List<String> cookies = con.getHeaderFields().get("Set-Cookie");
			cookieStr = String.join(";",cookies);
			
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	

	static private String cookieStr = null;
	static private final String[] tables = {
			"college_nine",
			"cowell",
			"crown",
			"porter",
			"rachel_carson"
	};
	static private final String[] urls = {
			"https://nutrition.sa.ucsc.edu/shortmenu.aspx?sName=UC+Santa+Cruz+Dining&locationNum=40&locationName=Colleges+Nine+%26+Ten+Dining+Hall&naFlag=1", 
			"https://nutrition.sa.ucsc.edu/shortmenu.aspx?sName=UC+Santa+Cruz+Dining&locationNum=05&locationName=Cowell+Stevenson+Dining+Hall&naFlag=1",
			"https://nutrition.sa.ucsc.edu/shortmenu.aspx?sName=UC+Santa+Cruz+Dining&locationNum=20&locationName=Crown+Merrill+Dining+Hall&naFlag=1",
			"https://nutrition.sa.ucsc.edu/shortmenu.aspx?sName=UC+Santa+Cruz+Dining&locationNum=25&locationName=Porter+Kresge+Dining+Hall&naFlag=1\n",
			"https://nutrition.sa.ucsc.edu/shortmenu.aspx?sName=UC+Santa+Cruz+Dining&locationNum=30&locationName=Rachel+Carson+Oakes+Dining+Hall&naFlag=1"
	};
	static private String[] dailyMeals = {
			"Breakfast", "Lunch", "Dinner"
	};
}
