package WebScrapper;

import java.util.LinkedList;
import java.sql.*;


public class dbUtil {
	
	private static Connection conn;
	public static void main(String[] args) {
		conn();
		LinkedList<String> test = new LinkedList<String>();
		connClose();
		
	}
	public static void InsertFood(String tName, LinkedList<String> foods, int id) {
		if(foods.size()==0)
			return;

		try {
            Statement stmt  = conn.createStatement();
            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO "+tName+" (category, available, rank, time, food, id) VALUES ");
            for(String food: foods) {
            	sql.append("(0, 0, 0, 1, \""+food+"\", "+id+" ), ");
            }
            sql.delete(sql.length()-2, sql.length() );
            System.out.println(sql.toString());
            
            stmt.execute(sql.toString());

            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

      }
	
	public static void IncrementTimeFood(String tName, LinkedList<String> foods, int id) {
		if(foods.size()==0)
			return;
		try {
            Statement stmt  = conn.createStatement();
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE "+tName+" SET time=time+1 WHERE ");
            for(String food: foods) {
            	sql.append("(food = \""+food+"\" AND id = "+id+") OR ");
            }
            sql.delete(sql.length()-4, sql.length() );
            System.out.println(sql.toString());
            
            stmt.execute(sql.toString());

            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

      }
	
	public static void UpdateIdFood(String tName, LinkedList<String> foods, int id) {
		if(foods.size()==0)
			return;
		try {
            Statement stmt  = conn.createStatement();
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE "+tName+" SET id = "+id+" WHERE ");
            for(String food: foods) {
            	sql.append("(food = \""+food+"\" AND id = "+id+") OR ");
            }
            sql.delete(sql.length()-4, sql.length() );
            System.out.println(sql.toString());
            
            stmt.execute(sql.toString());

            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

      }
	
	public static LinkedList<String> QueryFood(String tName, int id) {


		try {
            Statement stmt  = conn.createStatement();
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT food, id from "+tName);
            LinkedList<String> results = new LinkedList<String>();
            System.out.println(sql.toString());
            
            ResultSet rs = stmt.executeQuery(sql.toString());
            while(rs.next()) {
            	if(rs.getInt("id") == id)
            		results.add(rs.getString("food"));
            }
            System.out.println(results);
            stmt.close(); 
            rs.close();
            return results;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

      }
	
	public static void conn() {
		String URL = "jdbc:mysql://213.190.6.127:3306/u207738006_ihealthy";
        String USER = "u207738006_root";
        String PASSWORD = "123456";
        try {
            
        	Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	public static void connClose() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


}