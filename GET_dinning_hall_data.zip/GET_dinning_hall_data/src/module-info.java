module diningHallRating {
	requires org.jsoup;
	requires java.sql;
	requires mysql.connector.java;
}
